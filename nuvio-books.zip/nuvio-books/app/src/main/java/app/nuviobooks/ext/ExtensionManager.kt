package app.nuviobooks.ext

import app.nuviobooks.sources.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Isolation model: third-party extensions are DECLARATIVE (JSON manifests describing HTTP endpoints),
 * never downloaded code. That keeps them sandboxed by construction. Repository install/update is the next step.
 */
class ExtensionManager {
    val sources = MutableStateFlow<List<BookSource>>(listOf(Gutenberg, OpenLibrary, InternetArchive, LibriVox))
    val disabled = MutableStateFlow<Set<String>>(emptySet())
    fun toggle(id: String) { disabled.value = disabled.value.let { if (id in it) it - id else it + id } }
}

data class SearchOutcome(val books: List<Book>, val errors: Map<String, String>)

object UnifiedSearch {
    private fun key(b: Book) = b.title.lowercase().replace(Regex("[^a-z0-9]"), "") +
        "|" + (b.authors.firstOrNull()?.lowercase()?.split(" ")?.last().orEmpty()) + "|" + b.isAudio

    suspend fun search(q: String, sources: List<BookSource>): SearchOutcome = coroutineScope {
        val results = sources.map { s ->
            async { s.name to runCatching { withTimeout(12_000) { s.search(q) } } }
        }.awaitAll()
        val errors = results.filter { it.second.isFailure }.associate { it.first to (it.second.exceptionOrNull()?.message ?: "failed") }
        val merged = LinkedHashMap<String, Book>()
        results.flatMap { it.second.getOrDefault(emptyList()) }.forEach { b ->
            val k = key(b)
            val ex = merged[k]
            merged[k] = if (ex == null) b else ex.copy(
                formats = (ex.formats + b.formats).distinctBy { it.url },
                cover = ex.cover ?: b.cover, description = ex.description ?: b.description,
                alsoFrom = (ex.alsoFrom + b.source).distinct().filter { it != ex.source })
        }
        // downloadable books first
        SearchOutcome(merged.values.sortedByDescending { b -> b.formats.any { it.downloadable } }, errors)
    }
}
