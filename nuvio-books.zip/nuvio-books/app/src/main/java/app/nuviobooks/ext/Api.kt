package app.nuviobooks.ext

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class Format(val type: String, val url: String, val downloadable: Boolean)
data class Book(
    val id: String, val title: String, val authors: List<String>, val cover: String?,
    val description: String?, val language: String?, val formats: List<Format>,
    val source: String, val webUrl: String?, val isAudio: Boolean = false,
    val alsoFrom: List<String> = emptyList()
)

/** Standard extension contract. Every source (built-in or declarative) implements this. */
interface BookSource {
    val id: String
    val name: String
    suspend fun search(query: String): List<Book>
}

object Http {
    val client = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", "NuvioBooks/0.1").build()
        client.newCall(req).execute().use { check(it.isSuccessful) { "HTTP ${it.code}" }; it.body!!.string() }
    }
}
