package app.nuviobooks

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import app.nuviobooks.ext.*
import coil.compose.AsyncImage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SearchVM : ViewModel() {
    val ext = ExtensionManager()
    val state = MutableStateFlow(SearchOutcome(emptyList(), emptyMap()))
    val loading = MutableStateFlow(false)
    fun search(q: String) = viewModelScope.launch {
        loading.value = true
        val active = ext.sources.value.filter { it.id !in ext.disabled.value }
        state.value = UnifiedSearch.search(q, active)
        loading.value = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { SearchScreen() } } }
    }
}

@Composable
fun SearchScreen(vm: SearchVM = viewModel()) {
    val out by vm.state.collectAsState(); val loading by vm.loading.collectAsState()
    var q by remember { mutableStateOf("") }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search all sources") },
            trailingIcon = { TextButton({ if (q.isNotBlank()) vm.search(q) }) { Text("Go") } })
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        out.errors.forEach { (s, e) -> Text("$s unavailable: $e", color = MaterialTheme.colorScheme.error) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(out.books, key = { it.id }) { b ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(b.cover, null, Modifier.size(64.dp, 92.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                        Text(b.authors.joinToString(), style = MaterialTheme.typography.bodySmall)
                        Text((listOf(b.source) + b.alsoFrom).joinToString(" · ") + if (b.isAudio) " · audiobook" else "",
                            style = MaterialTheme.typography.labelSmall)
                        Text(b.formats.joinToString { it.type }, style = MaterialTheme.typography.labelSmall)
                        b.webUrl?.let { u -> TextButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }) { Text("Open source site") } }
                    }
                }
            }
        }
    }
}
