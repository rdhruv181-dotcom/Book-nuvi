package app.nuviobooks.sources

import app.nuviobooks.ext.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONArray
import org.json.JSONObject

private fun JSONArray?.strings() = this?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()

/** Open Library: metadata + links to public-domain scans (read online on archive.org). */
object OpenLibrary : BookSource {
    override val id = "openlibrary"; override val name = "Open Library"
    override suspend fun search(query: String): List<Book> {
        val url = "https://openlibrary.org/search.json".toHttpUrl().newBuilder()
            .addQueryParameter("q", query).addQueryParameter("limit", "20")
            .addQueryParameter("fields", "key,title,author_name,cover_i,language,ia,ebook_access").build()
        val docs = JSONObject(Http.get(url.toString())).getJSONArray("docs")
        return (0 until docs.length()).map { docs.getJSONObject(it) }.map { d ->
            val ia = d.optJSONArray("ia").strings().firstOrNull()
            val open = d.optString("ebook_access") == "public" && ia != null
            Book(
                id = d.getString("key"), title = d.getString("title"), authors = d.optJSONArray("author_name").strings(),
                cover = d.optInt("cover_i", 0).takeIf { it > 0 }?.let { "https://covers.openlibrary.org/b/id/$it-M.jpg" },
                description = null, language = d.optJSONArray("language").strings().firstOrNull(),
                formats = if (open) listOf(Format("web", "https://archive.org/details/$ia", false)) else emptyList(),
                source = name, webUrl = "https://openlibrary.org${d.getString("key")}"
            )
        }
    }
}

/** Project Gutenberg via the Gutendex API: public-domain EPUB/TXT downloads. */
object Gutenberg : BookSource {
    override val id = "gutenberg"; override val name = "Project Gutenberg"
    override suspend fun search(query: String): List<Book> {
        val url = "https://gutendex.com/books/".toHttpUrl().newBuilder().addQueryParameter("search", query).build()
        val res = JSONObject(Http.get(url.toString())).getJSONArray("results")
        return (0 until res.length()).map { res.getJSONObject(it) }.map { b ->
            val f = b.getJSONObject("formats")
            val fmts = f.keys().asSequence().mapNotNull { mime ->
                val t = when { mime.startsWith("application/epub") -> "EPUB"; mime.startsWith("text/plain") -> "TXT"; else -> null }
                t?.let { Format(it, f.getString(mime), true) }
            }.distinctBy { it.type }.toList()
            val authors = b.getJSONArray("authors").let { a -> (0 until a.length()).map { a.getJSONObject(it).getString("name") } }
            Book("pg${b.getInt("id")}", b.getString("title"), authors, f.optString("image/jpeg").ifEmpty { null },
                b.optJSONArray("summaries").strings().firstOrNull(), b.optJSONArray("languages").strings().firstOrNull(),
                fmts, name, "https://www.gutenberg.org/ebooks/${b.getInt("id")}")
        }
    }
}

/** Internet Archive texts. Many items are lending-only, so we link to the item page rather than downloading. */
object InternetArchive : BookSource {
    override val id = "ia"; override val name = "Internet Archive"
    override suspend fun search(query: String): List<Book> {
        val url = "https://archive.org/advancedsearch.php".toHttpUrl().newBuilder()
            .addQueryParameter("q", "title:($query) AND mediatype:texts AND access-restricted-item:false")
            .addQueryParameter("fl[]", "identifier").addQueryParameter("fl[]", "title").addQueryParameter("fl[]", "creator")
            .addQueryParameter("rows", "20").addQueryParameter("output", "json").build()
        val docs = JSONObject(Http.get(url.toString())).getJSONObject("response").getJSONArray("docs")
        return (0 until docs.length()).map { docs.getJSONObject(it) }.map { d ->
            val i = d.getString("identifier")
            Book("ia$i", d.optString("title", i), listOfNotNull(d.optString("creator").ifEmpty { null }),
                "https://archive.org/services/img/$i", null, null,
                listOf(Format("web", "https://archive.org/details/$i", false)), name, "https://archive.org/details/$i")
        }
    }
}

/** LibriVox: public-domain audiobooks. */
object LibriVox : BookSource {
    override val id = "librivox"; override val name = "LibriVox"
    override suspend fun search(query: String): List<Book> {
        val url = "https://librivox.org/api/feed/audiobooks".toHttpUrl().newBuilder()
            .addQueryParameter("title", "^$query").addQueryParameter("format", "json").addQueryParameter("limit", "20").build()
        val books = JSONObject(Http.get(url.toString())).optJSONArray("books") ?: return emptyList()
        return (0 until books.length()).map { books.getJSONObject(it) }.map { b ->
            val authors = b.optJSONArray("authors")?.let { a -> (0 until a.length()).map {
                a.getJSONObject(it).let { x -> "${x.optString("first_name")} ${x.optString("last_name")}".trim() } } } ?: emptyList()
            val zip = b.optString("url_zip_file")
            Book("lv${b.getString("id")}", b.getString("title"), authors, null, b.optString("description").ifEmpty { null },
                b.optString("language").ifEmpty { null },
                listOfNotNull(zip.takeIf { it.isNotEmpty() }?.let { Format("AUDIO", it, true) }),
                name, b.optString("url_librivox"), isAudio = true)
        }
    }
}
