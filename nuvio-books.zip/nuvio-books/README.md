# Nuvio Books (stage 1: extension engine + unified search)
Status: NOT compiled or run. Open in Android Studio (Koala+), sync, run.
Done: BookSource API, 4 real providers (Gutendex, Open Library, Internet Archive, LibriVox), parallel search with
timeouts, per-provider error isolation, de-duplication with merged sources/formats, Compose search UI.
Next: JSON-manifest extensions + repository install, Room library, EPUB/PDF reader, WorkManager downloads, Media3 audio.
